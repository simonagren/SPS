import { ActivityHandler } from 'botbuilder';
export declare class MyBot extends ActivityHandler {
    constructor();
}

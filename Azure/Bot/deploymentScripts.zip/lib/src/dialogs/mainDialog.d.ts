import { ComponentDialog, DialogState } from "botbuilder-dialogs";
import { Logger } from "../logger";
import { TurnContext, StatePropertyAccessor } from "botbuilder";
export declare class MainDialog extends ComponentDialog {
    private logger;
    constructor(logger: Logger);
    /**
     * The run method handles the incoming activity (in the form of a DialogContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {TurnContext} context
     */
    run(context: TurnContext, accessor: StatePropertyAccessor<DialogState>): Promise<void>;
    private introStep;
    /**
     * Main step in the waterall.  This will use LUIS to attempt to extract the title, site type, and owner.
     * Then, it hands off to the siteDialog child dialog to collect any remaining details.
     */
    private mainStep;
    /**
     * This is the final step in the main waterfall dialog.
     * It wraps up the sample "book a flight" interaction with a simple confirmation.
     */
    private finalStep;
}

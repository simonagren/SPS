export declare class SiteDetails {
    intent: string;
    siteType: string;
    siteDesign: string;
    title: string;
    description: string;
    owner: string;
    alias: string;
}

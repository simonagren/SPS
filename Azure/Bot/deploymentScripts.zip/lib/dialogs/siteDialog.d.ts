import { CancelAndHelpDialog } from './cancelAndHelpDialog';
export declare class SiteDialog extends CancelAndHelpDialog {
    constructor(id: string);
    /**
     * If a site type has not been provided, prompt for one.
     */
    private siteTypeStep;
    /**
     * If a site design has not been provided, prompt for one.
     */
    private siteDesignStep;
    /**
     * If a title has not been provided, prompt for one.
     */
    private titleStep;
    /**
     * If a description has not been provided, prompt for one.
     */
    private descriptionStep;
    /**
     * If an owner has not been provided, prompt for one.
     */
    private ownerStep;
    /**
     * If an owner has not been provided, prompt for one.
     */
    private aliasStep;
    /**
     * Confirm the information the user has provided.
     */
    private confirmStep;
    /**
     * Complete the interaction and end the dialog.
     */
    private finalStep;
}

import { SiteDetails } from './siteDetails';
import { TurnContext } from 'botbuilder';
import { Logger } from '../logger';
export declare class LuisHelper {
    /**
     * Returns an object with preformatted LUIS results for the bot's dialogs to consume.
     * @param {Logger} logger
     * @param {TurnContext} context
     */
    static executeLuisQuery(logger: Logger, context: TurnContext): Promise<SiteDetails>;
    private static parseCompositeEntity;
    private static parseTitleEntity;
    private static parseEmailEntity;
}

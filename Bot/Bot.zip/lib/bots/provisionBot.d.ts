/// <reference types="socket.io-client" />
import { ActivityHandler, BotState } from 'botbuilder';
import { Dialog } from 'botbuilder-dialogs';
import { Logger } from '../logger';
export declare class ProvisionBot extends ActivityHandler {
    private conversationState;
    private userState;
    private logger;
    private dialog;
    private dialogState;
    private conversationReferences;
    private socket;
    /**
     *
     * @param {BotState} conversationState
     * @param {BotState} userState
     * @param {Dialog} dialog
     * @param {Logger} logger object for logging events, defaults to console if none is provided
     * @param {Test[]} conversationReferences
     * @param {SocketIOClient.Socket} socket
     */
    constructor(conversationState: BotState, userState: BotState, dialog: Dialog, logger: Logger, conversationReferences: any, socket: SocketIOClient.Socket);
    private addConversationReference;
}

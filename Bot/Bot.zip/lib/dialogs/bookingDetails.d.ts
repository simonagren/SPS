export declare class BookingDetails {
    intent: string;
    origin: string;
    destination: string;
    travelDate: string;
}

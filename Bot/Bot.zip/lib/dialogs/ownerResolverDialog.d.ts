import { CancelAndHelpDialog } from './cancelAndHelpDialog';
export declare class OwnerResolverDialog extends CancelAndHelpDialog {
    private static textPromptValidator;
    private static validateEmail;
    private static userExists;
    constructor(id: string);
    private initialStep;
    private finalStep;
}

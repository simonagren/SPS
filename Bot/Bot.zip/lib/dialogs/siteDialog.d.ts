import { CancelAndHelpDialog } from './cancelAndHelpDialog';
import { Logger } from "../logger";
export declare class SiteDialog extends CancelAndHelpDialog {
    private logger;
    constructor(id: string, logger: Logger);
    /**
     * If a site type has not been provided, prompt for one.
     */
    private siteTypeStep;
    /**
     * If a title has not been provided, prompt for one.
     */
    private titleStep;
    /**
     * If a description has not been provided, prompt for one.
     */
    private descriptionStep;
    /**
     * If an owner has not been provided, prompt for one.
     */
    private ownerStep;
    /**
     * If an owner has not been provided, prompt for one.
     */
    private aliasStep;
    /**
     * Confirm the information the user has provided.
     */
    private confirmStep;
    /**
     * Complete the interaction and end the dialog.
     */
    private finalStep;
}

import { CancelAndHelpDialog } from './cancelAndHelpDialog';
export declare class AliasResolverDialog extends CancelAndHelpDialog {
    private static textPromptValidator;
    private static aliasExists;
    constructor(id: string);
    private initialStep;
    private finalStep;
}
